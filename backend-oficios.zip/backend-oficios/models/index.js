const { Sequelize } = require('sequelize');

// Configura tu conexión a la base de datos
const sequelize = new Sequelize('oficios_db', 'root', '', {
  host: 'localhost',
  port: 3307,        // Asegúrate de que el puerto sea correcto
  dialect: 'mysql'   // Aquí está la clave: especificamos el dialecto
});

module.exports = sequelize;
